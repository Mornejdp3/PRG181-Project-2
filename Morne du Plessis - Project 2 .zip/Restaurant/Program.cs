﻿using System.Collections;

namespace Restaurant
{
    internal class Program
    {
        //declare a global quantity variable to simplify the name (prevents me to declare a new variable each time)
        public static int quantity;
        public static double price;
        public static string meal;
        public static char cMealSize;
        public static string mealSize;

        //declare the cart variables
        public static double cartTotal;
        public static ArrayList cart = new();

        enum MainMenu//program main menu
        {
            breakfast = 1,
            pizza,
            pasta,
            burgers,
            drinks,
            cart,
            exit
        }//end mainmenu enum

        enum BreakfastMenu //breakfast menu
        {
            earlyBird = 1,
            streakyBreakfast,
            cheeseGriller,
            hashbrownBreakfast,
            mainMenu
        }//end breakfast enum

        enum PizzaMenu
        {
            margherita = 1,
            regina,
            tropical,
            tiAmo,
            napolitana,
            fourSeasons,
            chickenMayo,
            bbqChicken,
            mainMenu
        }//end pizza menu

        enum PastaMenu
        {
            seafoodPasta = 1,
            spagettiBolognaise,
            italianSpagettiMeatballs,
            chickenAvacado,
            penneTiAmo,
            portoChickenLiver,
            mainMenu
        }//end pasta menu

        enum BurgerMenu
        {
            original = 1,
            chicken,
            cheese,
            chickenCheese,
            mushroom,
            bbq,
            mainMenu
        }//end burger menu

        enum DrinksMenu
        {
            milkshakes = 1,
            sugarFreeSoftDrinks,
            softDrink,
            mainMenu
        }//end drinks menu

    static void Main(string[] args)
        {
            MainMenu:
            Console.Clear();
            Console.WriteLine("Welcome to The Restaurant. \n" +
                "\n" +
                "Please select an item from our menu: \n" +
                "\n" +
                "1. Breakfast\n" +
                "2. Pizza\n" +
                "3. Pasta\n" +
                "4. Burgers\n" +
                "5. Drinks\n" +
                "\n" +
                $"Your cart consists of {cart.Count} item(s). Your total is {cartTotal}\n" +
                $"6. Show cart items\n" +
                "7. Exit");

            int.TryParse(Console.ReadLine(), out int option);

            switch ((MainMenu)option)
            {
                case MainMenu.breakfast:
                    Breakfast();
                    goto MainMenu;

                case MainMenu.pizza:
                    Pizza();
                    goto MainMenu;

                case MainMenu.pasta:
                    Pasta();
                    goto MainMenu;

                case MainMenu.burgers:
                    Burgers();
                    goto MainMenu;

                case MainMenu.drinks:
                    Drinks();
                    goto MainMenu;

                case MainMenu.cart:
                    DisplayCart();
                    goto MainMenu;

                case MainMenu.exit:
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Invalid input!");
                    goto MainMenu;
            }//end switch
        }//end main method

        public static void Breakfast()
        {
            Breakfast:
            Console.Clear();
            Console.WriteLine("Breakfast: \n" +
                "\n" +
                "1. Early Bird \t (R42,90)\n" +
                "2. Streaky Breakfast \t (R49,90)\n" +
                "3. Cheese Griller \t (R54,90)\n" +
                "4. Hashbrown breakfast \t (R56,90)\n" +
                "\n" +
                "5. Exit");

            int.TryParse(Console.ReadLine(), out int optBreakfast);

            switch ((BreakfastMenu)optBreakfast)
            {
                case BreakfastMenu.earlyBird:
                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Early Bird";
                    price = 42.90;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Breakfast;

                case BreakfastMenu.streakyBreakfast:
                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Streaky Breakfast";
                    price = 49.90;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Breakfast;

                case BreakfastMenu.cheeseGriller:
                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Cheese Griller";
                    price = 54.90;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Breakfast;

                case BreakfastMenu.hashbrownBreakfast:
                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Hashbrown Breakfast";
                    price = 56.90;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Breakfast;

                case BreakfastMenu.mainMenu:
                    break; //exits out of the method

                default:
                    Console.WriteLine("Invalid option!");
                    goto Breakfast;
            }//end switch
            
        }//end breakfast method

        public static void Pizza()
        {
        Pizza:
            Console.Clear();
            Console.WriteLine("Pizza: \n" +
                "\n" +
                "1. Margherita\n" +
                "   Regular: R69.00 | Large: R79.00\n" +
                "2. Regina \n" +
                "   Regular: R95.00 | Large: R105.00\n" +
                "3.Tropical\n" +
                "   Regular: R95.00 | Large: R105.00\n" +
                "4. Ti Amo\n" +
                "   Regular: R99.00 | Large: R109.00\n" +
                "5. Napolitana\n" +
                "   Regular: R99.00 | Large: R109.00\n" +
                "6. Four Seasons\n" +
                "   Regular: R99.00 | Large: R109.00\n" +
                "7. Chicken Mayo\n" +
                "   Regular: R99.00 | Large: R109.00\n" +
                "8. BBQ Chicken\n" +
                "   Regular: R109.00 | Large: R119.00\n" +
                "\n" +
                "9. Exit\n");

            int.TryParse(Console.ReadLine(), out int optPizza);

            switch ((PizzaMenu)optPizza)
            {
                case PizzaMenu.margherita:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Margherita";
                    price = 69.00;

                //select the size
                Marg:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out  cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto Marg; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;

                    goto Pizza;

                case PizzaMenu.regina:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Regina";
                    price = 95.00;

                //select the size
                Regi:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto Regi; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;

                    goto Pizza;

                case PizzaMenu.tropical:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Tropical";
                    price = 95.00;

                //select the size
                Trop:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto Trop; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;
                    goto Pizza;

                case PizzaMenu.tiAmo:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Ti Amo";
                    price = 99.00;

                //select the size
                Ti:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto Ti; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;
                    goto Pizza;

                case PizzaMenu.napolitana:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Napolitana";
                    price = 99.00;

                //select the size
                Napo:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto Napo; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;
                    goto Pizza;

                case PizzaMenu.fourSeasons:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Four Seasons";
                    price = 99.00;

                //select the size
                Four:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto Four; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;
                    goto Pizza;

                case PizzaMenu.chickenMayo:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Chicken Mayo";
                    price = 99.00;

                //select the size
                Chic:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto Chic; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;
                    goto Pizza;

                case PizzaMenu.bbqChicken:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "BBQ Chicken";
                    price = 109.00;

                //select the size
                BBQ:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto BBQ; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;
                    goto Pizza;

                case PizzaMenu.mainMenu:
                    break; //exits out of the method

                default:
                    Console.WriteLine("Invalid option!");
                    goto Pizza;
            }//end switch
        }//end pizza method

        public static void Pasta()
        {
        Pasta:
            Console.Clear();
            Console.WriteLine("Pasta: \n" +
                "\n" +
                "1. Seafood Pasta \t (R149.99)\n" +
                "2. Spagetti Bolognaise \t (R99.99)\n" +
                "3. Italian spaghetti & MeatBalls \t (R109.99)\n" +
                "4. Chicken & Advocado \t (R129.99)\n" +
                "5. Penne Ti Amo \t (R129.99)\n" +
                "6. Porto Chicken Liver Pasta \t (R109.99)\n" +
                "\n" +
                "7. Exit\n");

            int.TryParse(Console.ReadLine(), out int optPasta);

            switch ((PastaMenu)optPasta)
            {
                case PastaMenu.seafoodPasta:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Seafood Pasta";
                    price = 149.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Pasta;

                case PastaMenu.spagettiBolognaise:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Spagetti Bolognaise";
                    price = 99.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Pasta;

                case PastaMenu.italianSpagettiMeatballs:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Italian Spagetti & Meatballs";
                    price = 109.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Pasta;

                case PastaMenu.chickenAvacado:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Chicken & Avacado";
                    price = 129.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Pasta;

                case PastaMenu.penneTiAmo:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Penne Ti Amo";
                    price = 129.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Pasta;

                case PastaMenu.portoChickenLiver:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Porto Chicken Liver";
                    price = 109.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Pasta;

                case PastaMenu.mainMenu:
                    break;//exits out of the method

                default:
                    Console.WriteLine("Invalid option");
                    goto Pasta;
            }//end switch
        }//end pasta method

        public static void Burgers()
        {
        Burgers:
            Console.Clear();
            Console.WriteLine("Burgers: \n" +
                "\n" +
                "1. Original Burger \t (R59.99)\n" +
                "2. Chicken Burger \t (R64.99)\n" +
                "3. Cheese Burger \t (R69.99)\n" +
                "4. Chicken Cheese Burger \t (R74.99)\n" +
                "5. Mushroom Burger \t (R74.99)\n" +
                "6. BBQ Burger \t (R79.99)\n" +
                "\n" +
                "7. Exit\n");

            int.TryParse(Console.ReadLine(), out int optBurgers);

            switch ((BurgerMenu)optBurgers)
            {
                case BurgerMenu.original:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Original Beef Burger";
                    price = 59.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Burgers;

                case BurgerMenu.chicken:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Original Chicken Burger";
                    price = 64.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Burgers;

                case BurgerMenu.cheese:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Cheese Beef Burger";
                    price = 69.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Burgers;

                case BurgerMenu.chickenCheese:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Chicken Cheese Burger";
                    price = 74.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Burgers;

                case BurgerMenu.mushroom:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "Mushroom Burger";
                    price = 74.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Burgers;

                case BurgerMenu.bbq:

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = "BBQ Burger";
                    price = 79.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Burgers;

                case BurgerMenu.mainMenu:
                    break;//exits the method

                default:
                    Console.WriteLine("Invalid input!");
                    goto Burgers;
            }//end switch
        }//end burgers method

        public static void Drinks()
        {
        Drinks:
            Console.Clear();
            string sFlavour = "";
            Console.WriteLine("Drinks: \n" +
                "\n" +
                "1. Milkshakes \n" +
                "   Regular: (R24.99) || Large: (R34.99)\n" +
                "2. Soft Drinks (Sugar-Free) \t (R10.99)\n" +
                "3. Soft Drinks \t (R14.99) \n" +
                "\n" +
                "4. Exit\n");

            int.TryParse(Console.ReadLine(), out int optDrinks);

            switch ((DrinksMenu)optDrinks)
            {
                case DrinksMenu.milkshakes:
                 
                    Console.Clear();
                    Console.WriteLine("Please select a falvour: \n" +
                        "\n" +
                        "1. Vanilla \n" +
                        "2. Chocolate \n" +
                        "3. Strawberry \n" +
                        "4. Banana \n" +
                        "5. Bubblegum \n" +
                        "6. Coffee \n");

                    int.TryParse(Console.ReadLine(), out int optFlavour);

                    switch (optFlavour)
                    {
                        case 1:
                            sFlavour = "Vanilla";
                            break;

                        case 2:
                            sFlavour = "Chocolate";
                            break;

                        case 3:
                            sFlavour = "Strawberry";
                            break;

                        case 4:
                            sFlavour = "Banana";
                            break;

                        case 5:
                            sFlavour = "Bubblegum";
                            break;

                        case 6:
                            sFlavour = "Coffee";
                            break;

                        default:
                            break;
                    }

                    //assign the meals details to the variables
                    quantity = 0;
                    meal = $"{sFlavour} Milkshake";
                    price = 24.99;

                //select the size
                MilkSize:
                    Console.WriteLine("Please select the size (r - regular || l - large):  ");
                    char.TryParse(Console.ReadLine(), out cMealSize);
                    switch (cMealSize)
                    {
                        case 'l':
                            mealSize = "Large";
                            price += 10;
                            break;

                        case 'r':
                            mealSize = "Regular";
                            break;

                        default:
                            Console.WriteLine("Incorrect value!");
                            goto MilkSize; //return to the size selection
                    }//end MealSize switch                    

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {mealSize} {meal} @ {price}");
                    cartTotal += price;

                    goto Drinks;

                case DrinksMenu.sugarFreeSoftDrinks:
                SugarFree:                        
                    Console.Clear();
                    Console.WriteLine("Please select a drink: \n" +
                        "\n" +
                        "1. Coke Zero\n" +
                        "2. Sprite Zero\n" +
                        "3. Stoney Zero\n");

                    int.TryParse(Console.ReadLine(), out int optSugarFree);

                    switch (optSugarFree)
                    {
                        case 1:
                            meal = "Coke Zero";
                            break;

                        case 2:
                            meal = "Sprite Zero";
                            break;

                        case 3:
                            meal = "Stoney Zero";
                            break;

                        default:
                            break;
                    }

                    //assign the meals details to the variables
                    quantity = 0;              
                    price = 10.99;           

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Drinks;

                case DrinksMenu.softDrink:

                SoftDrink:
                    Console.Clear();
                    Console.WriteLine("Please select a drink: \n" +
                        "\n" +
                        "1. Coke\n" +
                        "2. Cream Soda\n" +
                        "3. Sparberry\n" +
                        "4. Sprite\n" +
                        "5. Stoney\n" +
                        "6. Iced Tea");

                    int.TryParse(Console.ReadLine(), out int optSoftDrink);

                    switch (optSoftDrink)
                    {
                        case 1:
                            meal = "Coke";
                            break;

                        case 2:
                            meal = "Cream Soda";
                            break;

                        case 3:
                            meal = "Sparberry";
                            break;

                        case 4:
                            meal = "Sprite";
                            break;

                        case 5:
                            meal = "Stoney";
                            break;

                        case 6:
                            meal = "Iced Tea";
                            break;

                        default:
                            goto SoftDrink;
                    }

                    //assign the meals details to the variables
                    quantity = 0;
                    price = 14.99;

                    //select the quantity
                    Console.WriteLine("Please select the quantity:  ");
                    int.TryParse(Console.ReadLine(), out quantity);

                    //add the meal details to the cart
                    price = price * quantity;
                    cart.Add($"{quantity}x {meal} @ {price}");
                    cartTotal += price;

                    goto Drinks;

                case DrinksMenu.mainMenu:
                    break; //exits the method

                default:
                    Console.WriteLine("Invalid input!");
                    goto Drinks;
            }//end switch
        }//end drinks method

        public static void DisplayCart()
        {
            Console.Clear();
            Console.WriteLine("Cart: \n" +
                "\n");
            foreach (var item in cart)
            {
                Console.WriteLine(item);
            }//end foreach

            Console.WriteLine("\n Press any key to return to the main menu...");
            Console.ReadKey();
        }


    }//end program
}